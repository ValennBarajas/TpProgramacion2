﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using CineFront.Http;
using System.Drawing.Text;

namespace CineFront
{
    public partial class FrmComprar : Form
    {
        IServicio s;
        Comprobante comp;
        int vez;
        TicketDAO ticketDao;
        public FrmComprar()
        {
            InitializeComponent();
            comp = new Comprobante();
        }

        private void FrmComprar_Load(object sender, EventArgs e)
        {
            txtFechaCompra.Text = DateTime.Now.ToString("dd/MM/yyyy");
            CargarPeliculasAsync();
            this.ActiveControl = cboPelicula;
        }

        private async void CargarPeliculasAsync()
        {
            string url = "http://localhost:5031/peliculass";
            var result = await ClientSingleton.GetInstance().GetAsync(url);
            var lst = JsonConvert.DeserializeObject<List<Pelicula>>(result);
            cboPelicula.DataSource = lst;
            cboPelicula.DisplayMember = "titulo";
            cboPelicula.ValueMember = "cod_pelicula";
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (cboPelicula.Text.Equals(String.Empty))
            {
                MessageBox.Show("Debe seleccionar una PELICULA!", "Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (cboFuncion.Text.Equals(String.Empty))
            {
                MessageBox.Show("Debe ingresar una FUNCION!", "Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            foreach (DataGridViewRow row in dgvDetalles.Rows)
            {
                if (row.Cells["ColButaca"].Value.ToString().Equals(txtButaca.Text))
                {
                    MessageBox.Show("Butaca: " + txtButaca.Text + " ya se encuentra ocupada!", "Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;

                }
            }

            Pelicula p = (Pelicula)cboPelicula.SelectedItem;
            decimal precio = Convert.ToInt32(txtPrecio.Text);



            DetalleComprobante detalle = new DetalleComprobante(precio, butaca, descuento);
            nuevo.AgregarDetalle(detalle);
            dgvDetalles.Rows.Add(new object[] { p.ProductoNro, p.Nombre, p.Precio, txtCantidad.Text });

            DetalleComprobante(decimal precio, Butacas butaca1, decimal descuento)
        }

        private decimal CalcularMonto()
        {
            int precio
        }

        private void FrmComprar_Load_1(object sender, EventArgs e)
        {

        }

        private void dgvDetalles_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

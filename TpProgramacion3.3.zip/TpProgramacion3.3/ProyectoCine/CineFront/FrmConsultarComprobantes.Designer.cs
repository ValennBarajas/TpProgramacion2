﻿namespace CineFront
{
    partial class FrmConsultarComprobantes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnConsultar = new Button();
            txtCliente = new TextBox();
            dtpHasta = new DateTimePicker();
            dtpDesde = new DateTimePicker();
            lblCliente = new Label();
            lblFechaHasta = new Label();
            lblFechaDesde = new Label();
            dgvComprobantes = new DataGridView();
            ColID = new DataGridViewTextBoxColumn();
            ColNroComprobante = new DataGridViewTextBoxColumn();
            ColFecha = new DataGridViewTextBoxColumn();
            ColCliente = new DataGridViewTextBoxColumn();
            ColFuncion = new DataGridViewTextBoxColumn();
            ColButaca = new DataGridViewTextBoxColumn();
            ColAcciones = new DataGridViewButtonColumn();
            btnSalir = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvComprobantes).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnConsultar);
            groupBox1.Controls.Add(txtCliente);
            groupBox1.Controls.Add(dtpHasta);
            groupBox1.Controls.Add(dtpDesde);
            groupBox1.Controls.Add(lblCliente);
            groupBox1.Controls.Add(lblFechaHasta);
            groupBox1.Controls.Add(lblFechaDesde);
            groupBox1.Location = new Point(14, 14);
            groupBox1.Margin = new Padding(4, 3, 4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 3, 4, 3);
            groupBox1.Size = new Size(1050, 163);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Filtros";
            // 
            // btnConsultar
            // 
            btnConsultar.Location = new Point(886, 80);
            btnConsultar.Margin = new Padding(4, 3, 4, 3);
            btnConsultar.Name = "btnConsultar";
            btnConsultar.Size = new Size(158, 52);
            btnConsultar.TabIndex = 6;
            btnConsultar.Text = "Consultar";
            btnConsultar.UseVisualStyleBackColor = true;
            btnConsultar.Click += btnConsultar_Click;
            // 
            // txtCliente
            // 
            txtCliente.Location = new Point(128, 108);
            txtCliente.Margin = new Padding(4, 3, 4, 3);
            txtCliente.Name = "txtCliente";
            txtCliente.Size = new Size(714, 23);
            txtCliente.TabIndex = 5;
            // 
            // dtpHasta
            // 
            dtpHasta.Location = new Point(586, 45);
            dtpHasta.Margin = new Padding(4, 3, 4, 3);
            dtpHasta.Name = "dtpHasta";
            dtpHasta.Size = new Size(257, 23);
            dtpHasta.TabIndex = 4;
            // 
            // dtpDesde
            // 
            dtpDesde.Location = new Point(127, 45);
            dtpDesde.Margin = new Padding(4, 3, 4, 3);
            dtpDesde.Name = "dtpDesde";
            dtpDesde.Size = new Size(257, 23);
            dtpDesde.TabIndex = 3;
            // 
            // lblCliente
            // 
            lblCliente.AutoSize = true;
            lblCliente.Location = new Point(71, 113);
            lblCliente.Margin = new Padding(4, 0, 4, 0);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(47, 15);
            lblCliente.TabIndex = 2;
            lblCliente.Text = "Cliente:";
            // 
            // lblFechaHasta
            // 
            lblFechaHasta.AutoSize = true;
            lblFechaHasta.Location = new Point(496, 48);
            lblFechaHasta.Margin = new Padding(4, 0, 4, 0);
            lblFechaHasta.Name = "lblFechaHasta";
            lblFechaHasta.Size = new Size(74, 15);
            lblFechaHasta.TabIndex = 1;
            lblFechaHasta.Text = "Fecha Hasta:";
            // 
            // lblFechaDesde
            // 
            lblFechaDesde.AutoSize = true;
            lblFechaDesde.Location = new Point(34, 48);
            lblFechaDesde.Margin = new Padding(4, 0, 4, 0);
            lblFechaDesde.Name = "lblFechaDesde";
            lblFechaDesde.Size = new Size(76, 15);
            lblFechaDesde.TabIndex = 0;
            lblFechaDesde.Text = "Fecha Desde:";
            // 
            // dgvComprobantes
            // 
            dgvComprobantes.AllowUserToAddRows = false;
            dgvComprobantes.AllowUserToDeleteRows = false;
            dgvComprobantes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvComprobantes.Columns.AddRange(new DataGridViewColumn[] { ColID, ColNroComprobante, ColFecha, ColCliente, ColFuncion, ColButaca, ColAcciones });
            dgvComprobantes.Location = new Point(14, 194);
            dgvComprobantes.Margin = new Padding(4, 3, 4, 3);
            dgvComprobantes.Name = "dgvComprobantes";
            dgvComprobantes.ReadOnly = true;
            dgvComprobantes.Size = new Size(1050, 458);
            dgvComprobantes.TabIndex = 1;
            dgvComprobantes.CellContentClick += dgvComprobantes_CellContentClick;
            // 
            // ColID
            // 
            ColID.HeaderText = "ID";
            ColID.Name = "ColID";
            ColID.ReadOnly = true;
            ColID.Visible = false;
            ColID.Width = 120;
            // 
            // ColNroComprobante
            // 
            ColNroComprobante.HeaderText = "Comprobante #";
            ColNroComprobante.Name = "ColNroComprobante";
            ColNroComprobante.ReadOnly = true;
            ColNroComprobante.Width = 120;
            // 
            // ColFecha
            // 
            ColFecha.HeaderText = "Fecha de Pago";
            ColFecha.Name = "ColFecha";
            ColFecha.ReadOnly = true;
            ColFecha.Width = 150;
            // 
            // ColCliente
            // 
            ColCliente.HeaderText = "Cliente";
            ColCliente.Name = "ColCliente";
            ColCliente.ReadOnly = true;
            // 
            // ColFuncion
            // 
            ColFuncion.HeaderText = "Funcion";
            ColFuncion.Name = "ColFuncion";
            ColFuncion.ReadOnly = true;
            // 
            // ColButaca
            // 
            ColButaca.HeaderText = "Butaca";
            ColButaca.Name = "ColButaca";
            ColButaca.ReadOnly = true;
            // 
            // ColAcciones
            // 
            ColAcciones.HeaderText = "Acciones";
            ColAcciones.Name = "ColAcciones";
            ColAcciones.ReadOnly = true;
            ColAcciones.Text = "ELIMINAR";
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(472, 681);
            btnSalir.Margin = new Padding(4, 3, 4, 3);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(145, 50);
            btnSalir.TabIndex = 2;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // FrmConsultarComprobantes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1078, 744);
            Controls.Add(btnSalir);
            Controls.Add(dgvComprobantes);
            Controls.Add(groupBox1);
            Margin = new Padding(4, 3, 4, 3);
            Name = "FrmConsultarComprobantes";
            Text = "FrmConsultarComprobantes";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvComprobantes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label lblCliente;
        private Label lblFechaHasta;
        private Label lblFechaDesde;
        private Button btnConsultar;
        private TextBox txtCliente;
        private DateTimePicker dtpHasta;
        private DateTimePicker dtpDesde;
        private DataGridView dgvComprobantes;
        private Button btnSalir;
        private DataGridViewTextBoxColumn ColID;
        private DataGridViewTextBoxColumn ColNroComprobante;
        private DataGridViewTextBoxColumn ColFecha;
        private DataGridViewTextBoxColumn ColCliente;
        private DataGridViewTextBoxColumn ColFuncion;
        private DataGridViewTextBoxColumn ColButaca;
        private DataGridViewButtonColumn ColAcciones;
    }
}
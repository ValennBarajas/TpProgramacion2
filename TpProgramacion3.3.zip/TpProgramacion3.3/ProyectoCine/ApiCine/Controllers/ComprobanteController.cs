﻿using BibliotecaCine.Datos;
using BibliotecaCine.Datos.Fachada.Implementacion;
using BibliotecaCine.Datos.Fachada.Interfaz;
using BibliotecaCine.Datos.Implementacion;
using BibliotecaCine.Datos.Interfaz;
using BibliotecaCine.Entidades.Entrada;
using BibliotecaCine.Entidades.Peliculas;
using Microsoft.AspNetCore.Mvc;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ApiCine.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComprobanteController : ControllerBase
    {
        private readonly IApp app1;

        public ComprobanteController()
        {
            app1 = new App();
        }


        [HttpGet("Comprobantes")]
        public IActionResult GetComprobantePorFiltro([FromQuery] DateTime desde, [FromQuery] DateTime hasta, string cliente = "")
        {
            try
            {
                var lst = app1.ObtenerComprobantePorFiltro(desde, hasta, cliente);
                return Ok(lst);
            }
            catch (Exception)
            {
                return StatusCode(500, "Error interno! Intente luego");
            }
        }

        [HttpGet("Comprobante")]
        public IActionResult GetComprobantes()
        {
            try
            {
                var lst = app1.GetComprobantes();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "No se pudo traer lista de Generos");
            }
        }

        [HttpGet("Get Butacas")]
        public IActionResult GetButacas()
        {
            try
            {
                var lst = app1.GetButacas();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "No se pudo traer lista de Butacas");
            }
        }
        [HttpGet("Get FormaPago")]
        public IActionResult GetFormaPagos()
        {
            try
            {
                var lst = app1.GetFormaPagos();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "No se pudo traer lista de Butacas");
            }
        }

        [HttpGet("Get Detalle")]
        public IActionResult Detalle()
        {
            try
            {
                var lst = app1.GetDetalles();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "No se pudo traer lista de Butacas");
            }
        }

        [HttpPost("Consultar")]
        public IActionResult ObtenerComprobantes([FromBody] List<Comprobante> lst)
        {
            if (lst == null || lst.Count == 0)
                return BadRequest("Se requiere una lista de comprobantes");

            return Ok(lst);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] string value)
        {
            // Tu lógica para actualizar aquí
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            // Tu lógica para eliminar aquí
            return Ok();
        }
    }
}

﻿using BibliotecaCine.Datos.Fachada.Implementacion;
using BibliotecaCine.Datos.Fachada.Interfaz;
using BibliotecaCine.Entidades.Peliculas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiCine.Controllers
{
    public class PeliculaController : Controller
    {
        public IApp App1;

        public PeliculaController()
        {
            App1 = new App();
        }
        // GET: PeliculaController
        public ActionResult Index()
        {
            return View();
        }

        //[HttpGet("/Actores")]
        //public IActionResult GetProductos()
        //{
        //    List<Actor> lst = null;
        //    try
        //    {
        //        lst = App2.GetActores();
        //        return Ok(lst);

        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, "Error interno");
        //    }
        //}

        [HttpGet("/Peliculas")]
        public IActionResult GetPeliculas()
        {
            List<Pelicula> lst = null;
            try
            {
                lst = App1.GetPeliculas();
                return Ok(lst);

            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error interno");
            }
        }
        // GET: PeliculaController/Details/5
        
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PeliculaController/Create
        public ActionResult Create()
        {
            return View();
        }
        
        // POST: PeliculaController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [HttpGet("Repartos")]
        public IActionResult GetRepartos()
        {
            try
            {
                var lst = App1.GetRepartos();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "No se pudo traer lista de repartos");
            }
        }

        [HttpGet("Generos")]
        public IActionResult GetGeneros()
        {
            try
            {
                var lst = App1.GetGeneros();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "No se pudo traer lista de Generos");
            }
        }


        // GET: PeliculaController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }
       
        // POST: PeliculaController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        
        // GET: PeliculaController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }
        
        // POST: PeliculaController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}

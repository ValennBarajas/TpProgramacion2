﻿using BibliotecaCine.Datos.Fachada.Interfaz;
using BibliotecaCine.Datos.Implementacion;
using BibliotecaCine.Datos.Interfaz;
using BibliotecaCine.Entidades.Entrada;
using BibliotecaCine.Entidades.Peliculas;
using CineBack.Datos.Implementacion;
using CineBack.Datos.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Datos.Fachada.Implementacion
{
    public class App : IApp
    {
        private IDaoTicket dt;
        private IPeliculaDao ipl;

        public App()
        {
            dt = new TicketDAO();
            ipl = new PeliculaDao();
        }
        public List<Pelicula> GetPeliculas()
        {
            List<Pelicula> lst = ipl.GetPeliculas();
            return lst;
        }
        
        //public List<Actor> GetActores()
        //{
        //    List<Actor> lst = ipl.GetActors();
        //    return lst;
        //}
        public bool SavePresupuesto(Comprobante oComprobante)
        {
            return dt.Crear(oComprobante);
        }

        public List<Comprobante> GetComprobantes()
        {
            List<Comprobante> lst = dt.GetComprobantes();
            return lst;
        }

        public List<Reparto> GetRepartos()
        {
            List<Reparto> lst = ipl.GetReparto();
            return lst;
        }

        public List<Guia> GetGuias()
        {
            List<Guia> lst = ipl.GetGuia();
            return lst;
        }

        public List<Genero> GetGeneros()
        {
            List<Genero> lst = ipl.GetGenero();
            return lst;
        }

        public List<Comprobante> ObtenerComprobantePorFiltro(DateTime Desde, DateTime Hasta, string cliente)
        {
            List<Comprobante> lst = dt.ObtenerComprobantePorFiltros(Desde, Hasta, cliente);
            
            return lst;
        }
        public List<Butacas> GetButacas()
        {
            List<Butacas> lst = dt.ObtenerButacas();
            return lst;
        }
        public List<FormaPago> GetFormaPagos()
        {
            List<FormaPago> lst = dt.ObtenerFormasPago();
            return lst;
        }
        public List<DetalleComprobante> GetDetalles()
        {
            List<DetalleComprobante> lst = dt.ObtenerDetalles();
            return lst;
        }
    }
}

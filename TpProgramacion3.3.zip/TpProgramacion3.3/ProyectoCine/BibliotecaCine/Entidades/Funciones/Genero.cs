﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Peliculas
{
    public class Genero
    {
        public int id_genero { get; set; }
        public string genero { get; set; }
        public Genero(int id_genero, string genero)
        {
            this.id_genero = id_genero;
            this.genero = genero;
        }
    }
    
}

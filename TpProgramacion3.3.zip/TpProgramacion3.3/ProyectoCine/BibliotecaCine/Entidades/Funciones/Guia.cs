﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Peliculas
{
    public class Guia
    {
        public int idPG { get; set; }
        public int EdadMinima { get; set; }
        public Guia(int idPG, int edadMinima)
        {
            this.idPG = idPG;
            EdadMinima = edadMinima;
        }
    }
}

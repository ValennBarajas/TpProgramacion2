﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Peliculas
{
    public class Pelicula
    {
        
        public int CodPelicula { get; set; }
        public string Titulo { get; set; }
        public string Sinopsis { get; set; }
        public int IdPg { get; set; }
        public int IdGenero { get; set; }
        public int IdDirector { get; set; }
        public DateTime FechaEstreno { get; set; }
        public string Estado { get; set; }
        public List<Reparto> Repartos { get; set; }

        public Pelicula()
        {
                Repartos = new List<Reparto>();
        }
        public Pelicula(int codPelicula, string titulo, string sinopsis, int pg, int genero, int director, DateTime fechaEstreno, string estado)
        {
            CodPelicula=codPelicula;
            Titulo=titulo;
            Sinopsis=sinopsis;
            IdPg=pg;
            IdGenero=genero;
            IdDirector=director;
            FechaEstreno=fechaEstreno;
            Estado=estado;
        }
       
        public void AgregarDetalle(Reparto reparto)
        {
            Repartos.Add(reparto);
        }

        public void QuitarDetalle(int indice)
        {
            Repartos.RemoveAt(indice);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Peliculas
{
    public class Actor
    {
        public int Id_actor { get; set; }
        public string Nombre { get; set; }
        public string Ape_actor { get; set; }
        public Actor(int id_actor, string nombre, string ape_actor)
        {
            Id_actor = id_actor;
            Nombre = nombre;
            Ape_actor = ape_actor;
        }
    }
}

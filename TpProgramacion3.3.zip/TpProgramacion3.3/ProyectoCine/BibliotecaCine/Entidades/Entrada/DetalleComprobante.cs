﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Entrada
{
    public class DetalleComprobante
    {
        public decimal Precio { get; set; }
        public Butacas Butacas { get; }
        public decimal Descuento { get; set; }

        public DetalleComprobante(decimal precio, Butacas butaca, decimal descuento)
        {

            Precio = precio;
            Butacas = butaca;
            Descuento = descuento;
        }

    }
}

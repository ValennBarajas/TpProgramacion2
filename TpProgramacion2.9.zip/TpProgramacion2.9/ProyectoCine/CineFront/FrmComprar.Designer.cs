﻿namespace CineFront
{
    partial class FrmComprar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblReserva = new Label();
            txtReserva = new TextBox();
            btnSalir = new Button();
            btnComprar = new Button();
            txtSala = new TextBox();
            txtMonto = new TextBox();
            dtpFuncion = new DateTimePicker();
            cboFormaPago = new ComboBox();
            cboFuncion = new ComboBox();
            cboPelicula = new ComboBox();
            cboCliente = new ComboBox();
            lblSala = new Label();
            lblMonto = new Label();
            label6 = new Label();
            label5 = new Label();
            lblFuncion = new Label();
            lblPelicula = new Label();
            lblFechaCompra = new Label();
            lblCliente = new Label();
            lblButaca = new Label();
            txtButaca = new TextBox();
            txtFechaCompra = new TextBox();
            dgvDetalles = new DataGridView();
            ColId = new DataGridViewTextBoxColumn();
            ColFuncion = new DataGridViewTextBoxColumn();
            ColPelicula = new DataGridViewTextBoxColumn();
            ColButaca = new DataGridViewTextBoxColumn();
            ColSala = new DataGridViewTextBoxColumn();
            ColFechayHora = new DataGridViewTextBoxColumn();
            Acciones = new DataGridViewButtonColumn();
            btnAgregar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDetalles).BeginInit();
            SuspendLayout();
            // 
            // lblReserva
            // 
            lblReserva.AutoSize = true;
            lblReserva.Location = new Point(472, 456);
            lblReserva.Margin = new Padding(4, 0, 4, 0);
            lblReserva.Name = "lblReserva";
            lblReserva.Size = new Size(92, 15);
            lblReserva.TabIndex = 39;
            lblReserva.Text = "Codigo Reserva:";
            // 
            // txtReserva
            // 
            txtReserva.Location = new Point(578, 453);
            txtReserva.Margin = new Padding(4, 3, 4, 3);
            txtReserva.Name = "txtReserva";
            txtReserva.Size = new Size(114, 23);
            txtReserva.TabIndex = 38;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(791, 498);
            btnSalir.Margin = new Padding(4, 3, 4, 3);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(120, 40);
            btnSalir.TabIndex = 37;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            // 
            // btnComprar
            // 
            btnComprar.Location = new Point(366, 498);
            btnComprar.Margin = new Padding(4, 3, 4, 3);
            btnComprar.Name = "btnComprar";
            btnComprar.Size = new Size(253, 40);
            btnComprar.TabIndex = 36;
            btnComprar.Text = "Comprar";
            btnComprar.UseVisualStyleBackColor = true;
            // 
            // txtSala
            // 
            txtSala.Location = new Point(687, 105);
            txtSala.Margin = new Padding(4, 3, 4, 3);
            txtSala.Name = "txtSala";
            txtSala.Size = new Size(76, 23);
            txtSala.TabIndex = 35;
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(366, 453);
            txtMonto.Margin = new Padding(4, 3, 4, 3);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(90, 23);
            txtMonto.TabIndex = 34;
            // 
            // dtpFuncion
            // 
            dtpFuncion.Location = new Point(560, 64);
            dtpFuncion.Margin = new Padding(4, 3, 4, 3);
            dtpFuncion.Name = "dtpFuncion";
            dtpFuncion.Size = new Size(326, 23);
            dtpFuncion.TabIndex = 33;
            // 
            // cboFormaPago
            // 
            cboFormaPago.FormattingEnabled = true;
            cboFormaPago.Location = new Point(366, 410);
            cboFormaPago.Margin = new Padding(4, 3, 4, 3);
            cboFormaPago.Name = "cboFormaPago";
            cboFormaPago.Size = new Size(326, 23);
            cboFormaPago.TabIndex = 32;
            // 
            // cboFuncion
            // 
            cboFuncion.FormattingEnabled = true;
            cboFuncion.Location = new Point(560, 19);
            cboFuncion.Margin = new Padding(4, 3, 4, 3);
            cboFuncion.Name = "cboFuncion";
            cboFuncion.Size = new Size(326, 23);
            cboFuncion.TabIndex = 30;
            // 
            // cboPelicula
            // 
            cboPelicula.FormattingEnabled = true;
            cboPelicula.Location = new Point(122, 107);
            cboPelicula.Margin = new Padding(4, 3, 4, 3);
            cboPelicula.Name = "cboPelicula";
            cboPelicula.Size = new Size(326, 23);
            cboPelicula.TabIndex = 29;
            // 
            // cboCliente
            // 
            cboCliente.FormattingEnabled = true;
            cboCliente.Location = new Point(122, 21);
            cboCliente.Margin = new Padding(4, 3, 4, 3);
            cboCliente.Name = "cboCliente";
            cboCliente.Size = new Size(326, 23);
            cboCliente.TabIndex = 28;
            cboCliente.SelectedIndexChanged += cboCliente_SelectedIndexChanged;
            // 
            // lblSala
            // 
            lblSala.AutoSize = true;
            lblSala.Location = new Point(648, 110);
            lblSala.Margin = new Padding(4, 0, 4, 0);
            lblSala.Name = "lblSala";
            lblSala.Size = new Size(31, 15);
            lblSala.TabIndex = 27;
            lblSala.Text = "Sala:";
            // 
            // lblMonto
            // 
            lblMonto.AutoSize = true;
            lblMonto.Location = new Point(305, 457);
            lblMonto.Margin = new Padding(4, 0, 4, 0);
            lblMonto.Name = "lblMonto";
            lblMonto.Size = new Size(46, 15);
            lblMonto.TabIndex = 26;
            lblMonto.Text = "Monto:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(474, 69);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(79, 15);
            label6.TabIndex = 25;
            label6.Text = "Fecha y Hora:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(261, 413);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(90, 15);
            label5.TabIndex = 24;
            label5.Text = "Forma de Pago:";
            // 
            // lblFuncion
            // 
            lblFuncion.AutoSize = true;
            lblFuncion.Location = new Point(500, 23);
            lblFuncion.Margin = new Padding(4, 0, 4, 0);
            lblFuncion.Name = "lblFuncion";
            lblFuncion.Size = new Size(53, 15);
            lblFuncion.TabIndex = 23;
            lblFuncion.Text = "Función:";
            // 
            // lblPelicula
            // 
            lblPelicula.AutoSize = true;
            lblPelicula.Location = new Point(60, 113);
            lblPelicula.Margin = new Padding(4, 0, 4, 0);
            lblPelicula.Name = "lblPelicula";
            lblPelicula.Size = new Size(51, 15);
            lblPelicula.TabIndex = 22;
            lblPelicula.Text = "Pelicula:";
            // 
            // lblFechaCompra
            // 
            lblFechaCompra.AutoSize = true;
            lblFechaCompra.Location = new Point(8, 64);
            lblFechaCompra.Margin = new Padding(4, 0, 4, 0);
            lblFechaCompra.Name = "lblFechaCompra";
            lblFechaCompra.Size = new Size(103, 15);
            lblFechaCompra.TabIndex = 21;
            lblFechaCompra.Text = "Fecha de Compra:";
            // 
            // lblCliente
            // 
            lblCliente.AutoSize = true;
            lblCliente.Location = new Point(64, 25);
            lblCliente.Margin = new Padding(4, 0, 4, 0);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(47, 15);
            lblCliente.TabIndex = 20;
            lblCliente.Text = "Cliente:";
            // 
            // lblButaca
            // 
            lblButaca.AutoSize = true;
            lblButaca.Location = new Point(507, 107);
            lblButaca.Margin = new Padding(4, 0, 4, 0);
            lblButaca.Name = "lblButaca";
            lblButaca.Size = new Size(46, 15);
            lblButaca.TabIndex = 40;
            lblButaca.Text = "Butaca:";
            // 
            // txtButaca
            // 
            txtButaca.Location = new Point(560, 105);
            txtButaca.Margin = new Padding(4, 3, 4, 3);
            txtButaca.Name = "txtButaca";
            txtButaca.Size = new Size(69, 23);
            txtButaca.TabIndex = 41;
            // 
            // txtFechaCompra
            // 
            txtFechaCompra.Location = new Point(122, 61);
            txtFechaCompra.Margin = new Padding(4, 3, 4, 3);
            txtFechaCompra.Name = "txtFechaCompra";
            txtFechaCompra.Size = new Size(326, 23);
            txtFechaCompra.TabIndex = 42;
            // 
            // dgvDetalles
            // 
            dgvDetalles.AllowUserToAddRows = false;
            dgvDetalles.AllowUserToDeleteRows = false;
            dgvDetalles.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDetalles.Columns.AddRange(new DataGridViewColumn[] { ColId, ColFuncion, ColPelicula, ColButaca, ColSala, ColFechayHora, Acciones });
            dgvDetalles.Location = new Point(12, 151);
            dgvDetalles.Name = "dgvDetalles";
            dgvDetalles.ReadOnly = true;
            dgvDetalles.RowTemplate.Height = 25;
            dgvDetalles.Size = new Size(899, 241);
            dgvDetalles.TabIndex = 43;
            // 
            // ColId
            // 
            ColId.HeaderText = "ID";
            ColId.Name = "ColId";
            ColId.ReadOnly = true;
            ColId.Visible = false;
            // 
            // ColFuncion
            // 
            ColFuncion.HeaderText = "Funcion";
            ColFuncion.Name = "ColFuncion";
            ColFuncion.ReadOnly = true;
            ColFuncion.Width = 150;
            // 
            // ColPelicula
            // 
            ColPelicula.HeaderText = "Pelicula";
            ColPelicula.Name = "ColPelicula";
            ColPelicula.ReadOnly = true;
            ColPelicula.Width = 200;
            // 
            // ColButaca
            // 
            ColButaca.HeaderText = "Butaca";
            ColButaca.Name = "ColButaca";
            ColButaca.ReadOnly = true;
            // 
            // ColSala
            // 
            ColSala.HeaderText = "Sala";
            ColSala.Name = "ColSala";
            ColSala.ReadOnly = true;
            // 
            // ColFechayHora
            // 
            ColFechayHora.HeaderText = "Fecha y Hora";
            ColFechayHora.Name = "ColFechayHora";
            ColFechayHora.ReadOnly = true;
            ColFechayHora.Width = 200;
            // 
            // Acciones
            // 
            Acciones.HeaderText = "Acciones";
            Acciones.Name = "Acciones";
            Acciones.ReadOnly = true;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(791, 101);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(104, 41);
            btnAgregar.TabIndex = 44;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            // 
            // FrmComprar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(924, 550);
            Controls.Add(btnAgregar);
            Controls.Add(dgvDetalles);
            Controls.Add(txtFechaCompra);
            Controls.Add(txtButaca);
            Controls.Add(lblButaca);
            Controls.Add(lblReserva);
            Controls.Add(txtReserva);
            Controls.Add(btnSalir);
            Controls.Add(btnComprar);
            Controls.Add(txtSala);
            Controls.Add(txtMonto);
            Controls.Add(dtpFuncion);
            Controls.Add(cboFormaPago);
            Controls.Add(cboFuncion);
            Controls.Add(cboPelicula);
            Controls.Add(cboCliente);
            Controls.Add(lblSala);
            Controls.Add(lblMonto);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(lblFuncion);
            Controls.Add(lblPelicula);
            Controls.Add(lblFechaCompra);
            Controls.Add(lblCliente);
            Margin = new Padding(4, 3, 4, 3);
            Name = "FrmComprar";
            Text = "FrmComprar";
            Load += FrmComprar_Load_1;
            ((System.ComponentModel.ISupportInitialize)dgvDetalles).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblReserva;
        private TextBox txtReserva;
        private Button btnSalir;
        private Button btnComprar;
        private TextBox txtSala;
        private TextBox txtMonto;
        private DateTimePicker dtpFuncion;
        private ComboBox cboFormaPago;
        private ComboBox cboFuncion;
        private ComboBox cboPelicula;
        private ComboBox cboCliente;
        private Label lblSala;
        private Label lblMonto;
        private Label label6;
        private Label label5;
        private Label lblFuncion;
        private Label lblPelicula;
        private Label lblFechaCompra;
        private Label lblCliente;
        private Label lblButaca;
        private TextBox txtButaca;
        private TextBox txtFechaCompra;
        private DataGridView dgvDetalles;
        private DataGridViewTextBoxColumn ColId;
        private DataGridViewTextBoxColumn ColFuncion;
        private DataGridViewTextBoxColumn ColPelicula;
        private DataGridViewTextBoxColumn ColButaca;
        private DataGridViewTextBoxColumn ColSala;
        private DataGridViewTextBoxColumn ColFechayHora;
        private DataGridViewButtonColumn Acciones;
        private Button btnAgregar;
    }
}
﻿using BibliotecaCine.Datos;
using BibliotecaCine.Datos.Fachada.Implementacion;
using BibliotecaCine.Datos.Fachada.Interfaz;
using BibliotecaCine.Datos.Implementacion;
using BibliotecaCine.Datos.Interfaz;
using BibliotecaCine.Entidades.Entrada;
using BibliotecaCine.Entidades.Peliculas;
using Microsoft.AspNetCore.Mvc;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ApiCine.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComprobanteController : ControllerBase
    {   
        
        public IApp app1;

        public ComprobanteController()
        {
            app1 = new App();
        }

        // GET: api/<ComprobanteController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<ComprobanteController>/5
        [HttpGet("/Comprobantes")]
        public IActionResult GetFunciones()
        {
            List<Comprobante> lst = null;
            try
            {
                lst = app1.GetComprobantes();
                return Ok(lst);
            }
            catch (Exception ex)
            {
                return StatusCode(404, "No se pudo traer lista de comprobantes");
            }
        }


        [HttpPost("Consultar")]
        public IActionResult ObtenerComprobantes(List<Parametro> lst)
        {
            if (lst == null || lst.Count == 0)

                return BadRequest("Se requiere una lista de peliculas");

            return Ok((lst));
        }

        // PUT api/<ComprobanteController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ComprobanteController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

﻿using BibliotecaCine.Entidades.Entrada;
using BibliotecaCine.Entidades.Peliculas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Datos.Fachada.Interfaz
{
    public interface IApp
    {
        public List<Pelicula> GetPeliculas();
        public List<Comprobante> GetComprobantes();
        public List<Guia> GetGuias();
        public List<Genero> GetGeneros();
        public List<Reparto> GetRepartos();
    }
}

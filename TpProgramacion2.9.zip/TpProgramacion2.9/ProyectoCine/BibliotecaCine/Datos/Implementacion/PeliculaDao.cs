﻿using BibliotecaCine.Datos;
using BibliotecaCine.Entidades.Peliculas;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CineBack.Datos.Interfaz;

namespace CineBack.Datos.Implementacion
{
    public class PeliculaDao : IPeliculaDao
    {
        public List<Pelicula> GetPeliculas()
        {
            List<Pelicula> lstPeliculas = new List<Pelicula>();

            string sp = "SP_CONSULTAR_PELICULA";
            DataTable table = HelperDB.ObtenerInstancia().ConsultaSQL(sp, null);

            foreach (DataRow dr in table.Rows)
            {
                int nro = int.Parse(dr["cod_pelicula"].ToString());
                string nombre = dr["pelicula"].ToString();
                string sinopsis = dr["sinopsis"].ToString();
                int id_pg = int.Parse(dr["id_PG"].ToString());
                int id_genero = int.Parse(dr["id_genero"].ToString());
                int id_director = int.Parse(dr["id_director"].ToString());
                DateTime fecha = DateTime.Parse(dr["fecha_orden"].ToString());
                
                string estado = dr["estado"].ToString();

                Pelicula aux = new Pelicula(nro, nombre, sinopsis, id_pg, id_genero, id_director, fecha, estado);
                lstPeliculas.Add(aux);
            }
            return lstPeliculas;
        }
        public List<Reparto> GetReparto()
        {
            List<Reparto> lst = new List<Reparto>();

            string sp = "sp_consultar_reparto";
            DataTable t = HelperDB.ObtenerInstancia().ConsultaSQL(sp, null);

            foreach (DataRow fila in t.Rows)
            {

                int Id = Convert.ToInt32(fila[0].ToString());
                string puesto = fila[2].ToString();
                string esp = "sp_consultar_actores";
                DataTable tabla = HelperDB.ObtenerInstancia().ConsultaSQL(esp, null);
                foreach (DataRow d in tabla.Rows)
                {
                    if (Convert.ToInt32(fila[1]) == Convert.ToInt32(d[0]))
                    {
                        int actor = Convert.ToInt32(d[0].ToString());
                        string nombre = fila[1].ToString();
                        string apellido = fila[2].ToString();
                        Actor a = new Actor(actor, nombre, apellido);
                        Reparto r = new Reparto(Id, a, puesto);
                        lst.Add(r);
                    }
                }

            }
            return lst;
        }

        public bool CrearPelicula(Pelicula oPelicula)
        {
            bool ok = true;
            SqlConnection con = null;
            SqlTransaction tran = null;

            try
            {
                con = HelperDB.ObtenerInstancia().ObtenerConexion();
                con.Open();
                tran = con.BeginTransaction();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.Transaction = tran;

                cmd.CommandText = "SP_INSERTAR_PELICULAS";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@titulo", oPelicula.Titulo);
                cmd.Parameters.AddWithValue("@sinopsis", oPelicula.Sinopsis);
                cmd.Parameters.AddWithValue("@pg", oPelicula.IdPg);
                cmd.Parameters.AddWithValue("@genero", oPelicula.IdGenero);
                cmd.Parameters.AddWithValue("@director", oPelicula.IdDirector);

                SqlParameter pOut = new SqlParameter();
                pOut.ParameterName = "@pelicula_nro";
                pOut.DbType = DbType.Int32;
                pOut.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pOut);
                cmd.ExecuteNonQuery();

                int nroPelicula = (int)pOut.Value;

                SqlCommand cmdReparto;
                int repartoNro = 1;
                foreach (Reparto item in oPelicula.Repartos)
                {
                    cmdReparto = new SqlCommand("SP_INSERTAR_REPARTO", con, tran);
                    cmdReparto.CommandType = CommandType.StoredProcedure;
                    cmdReparto.Parameters.AddWithValue("@reparto", item.Id);
                    cmdReparto.Parameters.AddWithValue("@actor", item.Actor);
                    cmdReparto.Parameters.AddWithValue("@cod_pelicula", nroPelicula);
                    cmdReparto.Parameters.AddWithValue("@puesto", item.Puesto);
                    cmdReparto.ExecuteNonQuery();

                    repartoNro++;
                }
                tran.Commit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al crear la función: " + ex.Message);
                if (tran != null)
                    tran.Rollback();
                ok = false;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

            return ok;
        }
        public List<Reparto> GetReparto(int pelicula)
        {
            List<Reparto> lst = new List<Reparto>();

            string sp = "sp_consultar_reparto";
            DataTable t = HelperDB.ObtenerInstancia().ConsultaSQL(sp, null);

            foreach (DataRow fila in t.Rows)
            {
                if (Convert.ToInt32(fila[2]) == pelicula)
                {
                    int Id = Convert.ToInt32(fila[0].ToString());
                    string puesto = fila[2].ToString();
                    string esp = "sp_consultar_actores";
                    DataTable tabla = HelperDB.ObtenerInstancia().ConsultaSQL(esp, null);
                    foreach (DataRow d in tabla.Rows)
                    {
                        if (Convert.ToInt32(fila[1]) == Convert.ToInt32(d[0]))
                        {
                            int actor = Convert.ToInt32(d[0].ToString());
                            string nombre = fila[1].ToString();
                            string apellido = fila[2].ToString();
                            Actor a = new Actor(actor,nombre,apellido);
                            Reparto r = new Reparto(Id, a, puesto);
                            lst.Add(r);
                        }
                    }
                    
                }
                
            }
            return lst;
        }

        public List<Genero> GetGenero()
        {
            
            List<Genero> lst = new List<Genero>();

            string sp = "sp_consultar_genero";
            DataTable t = HelperDB.ObtenerInstancia().ConsultaSQL(sp, null);

                foreach (DataRow fila in t.Rows)
                {
                    int Id = Convert.ToInt32(fila[0].ToString());
                    string genero = fila[1].ToString();
                    Genero g = new Genero(Id, genero);
                    lst.Add(g);
                }
            return lst;
            
        }

        public List<Guia> GetGuia()
        {
            List<Guia> lst = new List<Guia>();

            string sp = "sp_consultar_guia";
            DataTable t = HelperDB.ObtenerInstancia().ConsultaSQL(sp, null);

            foreach (DataRow fila in t.Rows)
            {
                int idPG = Convert.ToInt32(fila[0].ToString());
                int EdadMinima = Convert.ToInt32(fila[1].ToString());
                Guia d = new Guia(idPG, EdadMinima);
                lst.Add(d);
            }
            return lst;
        }
        public List<Director> GetDirectores()
        {
            List<Director> lst = new List<Director>();

            string sp = "sp_consultar_genero";
            DataTable t = HelperDB.ObtenerInstancia().ConsultaSQL(sp, null);

            foreach (DataRow fila in t.Rows)
            {
                int Id = Convert.ToInt32(fila[0].ToString());
                string nombre = fila[1].ToString();
                string apellido = fila[2].ToString();
                Director d = new Director(Id,nombre, apellido);
                lst.Add(d);
            }
            return lst;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Peliculas
{
    public class Reparto
    {
        public int Id { get; set; }
        public Actor Actor { get; set; }
        public string Puesto { get; set; }
        public Reparto(int id, Actor actor, string puesto)
        {
            Id = id;
            Actor = actor;
            Puesto = puesto;
            
        }
    }
}

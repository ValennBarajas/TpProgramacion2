﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCine.Entidades.Peliculas
{
    public class Director
    {
        public int Id_Director { get; set; }

        public string Nom_Director { get; set; }

        public string Ape_Director { get; set; }

        public Director(int id_Director, string nom_Director, string ape_Director)
        {
            Id_Director = id_Director;
            Nom_Director = nom_Director;
            Ape_Director = ape_Director;
        }
    }
}
